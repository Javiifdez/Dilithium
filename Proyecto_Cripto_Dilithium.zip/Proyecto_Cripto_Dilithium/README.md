# Implementación de CRYSTALS-Dilithium

Criptografía Poscuántica — Universidad Francisco de Vitoria (UFV)

**Autores:** David Sanz Fuertes, María Rivas Ramos, Javier Fernández Meroño
**Fecha de entrega:** 8 de mayo de 2026

## Resumen

Dilithium es un esquema de firma digital resistente a ataques cuánticos, seleccionado por el NIST en su proceso de estandarización de criptografía poscuántica y recogido en el estándar **FIPS 204**. A diferencia de esquemas como RSA-PSS o ECDSA, cuya seguridad depende de la factorización de enteros o el logaritmo discreto (rompibles mediante el algoritmo de Shor), Dilithium basa su seguridad en la dificultad de problemas sobre retículas modulares, concretamente **Module-SIS (M-SIS)** y **Module-LWE (M-LWE)**.

Este repositorio contiene una implementación funcional en **SageMath/Python** de las tres operaciones del esquema:

- **KeyGen** — genera la matriz pública `A` y el par de claves `(pk, sk)` a partir de un secreto `s1, s2` con coeficientes pequeños, calculando `t = A·s1 + s2`.
- **Sign** — firma un mensaje mediante la técnica de **Fiat-Shamir con abortos** (Lyubashevsky, 2009): se muestrea un vector aleatorio `y`, se deriva un desafío `c` del hash del mensaje, y se calcula `z = y + c·s1`, reintentando si `z` supera el umbral de seguridad.
- **Verify** — verifica la firma reconstruyendo `w' = A·z - c·t` y comprobando que el desafío recalculado coincide con el recibido.

## Fundamentos matemáticos

- **Retículas y problema SIS/M-SIS**: la seguridad se reduce a encontrar un vector corto no nulo `z` tal que `Az = 0 (mod q)`, problema considerado intratable incluso para ordenadores cuánticos.
- **Anillo de polinomios** `Rq = Zq[x] / (x^n + 1)`, con `n = 256` y `q = 8.380.417`.
- **NTT (Number Theoretic Transform)**: permite multiplicar polinomios en `O(n log n)` en lugar de `O(n²)`.
- **Fiat-Shamir con abortos**: garantiza que la firma `z` no filtra información sobre el secreto `s`, rechazando y reintentando cuando `‖z‖∞ ≥ γ1 − β`.

## Contenido del repositorio

- `Implementacion.ipynb` — Notebook de SageMath con la implementación completa (KeyGen, Sign, Verify) y una prueba de firma/verificación de un mensaje.

## Requisitos

- [SageMath](https://www.sagemath.org/) (kernel SageMath 10.8 o compatible)
- Librerías estándar de Python: `hashlib`, `struct`, `os`, `time`

## Cómo ejecutar

1. Abrir `Implementacion.ipynb` con Jupyter y el kernel de SageMath.
2. Ejecutar las celdas en orden: carga de parámetros → `keygen()` → `sign()` → `verify()`.
3. La celda de prueba genera un par de claves, firma un mensaje y verifica tanto el mensaje original como uno modificado (para comprobar que la firma se invalida correctamente).

## Parámetros usados

| Parámetro | Valor |
|---|---|
| q | 8.380.417 |
| n | 256 |
| k, l | 4, 4 |
| η (eta) | 2 |
| γ1 (gamma1) | 2^17 |
| γ2 (gamma2) | (q-1)/88 |
| τ (tau) | 39 |

Corresponde a una variante equivalente a **Dilithium2** (128 bits de seguridad).

## Licencia

Proyecto académico desarrollado en el marco de la asignatura de Criptografía, UFV.
